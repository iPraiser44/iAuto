	window.onload = function(){

	var idButton = document.getElementById("idButton")

   
    idButton.addEventListener('click', function() { chrome.tabs.create({url: "https://www.agarz.com"}); });

}